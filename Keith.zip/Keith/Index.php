<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Keith's Closet - Supporting Mental Health Through Clothing">
    <title>Keith's Closet</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header class="site-header">
        <div class="header-container">
            <img src="images/keiths-logo.png" alt="Keith's Closet Logo" class="site-logo">
            <div class="social-media-links">
                <a href="https://facebook.com" target="_blank" aria-label="Facebook">
                    <i class="fab fa-facebook-f"></i>
                </a>
                <a href="https://instagram.com" target="_blank" aria-label="Instagram">
                    <i class="fab fa-instagram"></i>
                </a>
                <a href="https://twitter.com" target="_blank" aria-label="Twitter">
                    <i class="fab fa-twitter"></i>
                </a>
            </div>
            <div class="cta-buttons">
                <?php if(isset($_SESSION['volunteer_logged_in'])): ?>
                    <a href="pages/dashboard.php" class="volunteer-btn">Dashboard</a>
                <?php else: ?>
                    <a href="pages/auth.php" class="volunteer-btn">Become a Volunteer</a>
                <?php endif; ?>
            </div>
        </div>
        <div class="menu-toggle" id="menu-toggle" aria-label="Open Menu">
            <div class="toggle-bar"></div>
            <div class="toggle-bar"></div>
            <div class="toggle-bar"></div>
        </div>
    </header>

    <!-- Fullscreen Menu -->
    <nav id="fullscreen-menu" class="fullscreen-menu hidden" aria-hidden="true">
        <a href="#" class="menu-close-btn" id="menu-close-btn" aria-label="Close Menu">&times;</a>
        <div class="menu-content">
            <img src="images/keiths-logo.png" alt="Keith's Closet Logo" class="menu-logo">
            <ul class="nav-list">
                <li><a href="#about">About</a></li>
                <li><a href="#charity-partners">Charity Partners</a></li>
                <li><a href="#fashion-partners">Fashion Partners</a></li>
                <li><a href="#our-supporters">Our Supporters</a></li>
                <li><a href="#meet-the-team">Meet the Team</a></li>
                <li><a href="#volunteer">Volunteer</a></li>
                <li><a href="#donate">Donate</a></li>
                <li><a href="#media">Media</a></li>
                <li><a href="#shop">Shop</a></li>
            </ul>
        </div>
    </nav>

    <!-- The rest of your HTML content remains the same -->

    <!-- Footer -->
    <footer class="site-footer">
        <div class="footer-container">
            <p>&copy; 2024 Keith's Closet. All Rights Reserved.</p>
        </div>
    </footer>

    <script src="scripts.js"></script>
</body> 
</html>
