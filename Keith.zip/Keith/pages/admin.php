<?php
session_start();
require_once '../config/db.php';

// Ensure the admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

// Handle volunteer deletion
if (isset($_POST['delete_volunteer'])) {
    $volunteer_id = $_POST['volunteer_id'];
    $stmt = $pdo->prepare("DELETE FROM volunteers WHERE id = ?");
    $stmt->execute([$volunteer_id]);
    header('Location: admin.php');
    exit();
}

// Fetch all volunteers
$search_query = '';
if (isset($_GET['search'])) {
    $search_query = $_GET['search'];
    $stmt = $pdo->prepare("SELECT * FROM volunteers WHERE username LIKE ? OR email LIKE ?");
    $stmt->execute(['%' . $search_query . '%', '%' . $search_query . '%']);
} else {
    $stmt = $pdo->query("SELECT * FROM volunteers");
}
$volunteers = $stmt->fetchAll();

// Handle volunteer approval status toggle
if (isset($_POST['toggle_approval'])) {
    $volunteer_id = $_POST['volunteer_id'];
    $is_approved = $_POST['is_approved'] ? 0 : 1; // Toggle between 0 and 1
    $stmt = $pdo->prepare("UPDATE volunteers SET is_approved = ? WHERE id = ?");
    $stmt->execute([$is_approved, $volunteer_id]);
    header('Location: admin.php');
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Add your own styles here -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .admin-container {
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .search-bar {
            text-align: center;
            margin: 20px 0;
        }

        .search-bar input[type="text"] {
            width: 300px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: center;
        }

        .approve-btn, .delete-btn {
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            border: none;
            color: #fff;
        }

        .approve-btn {
            background-color: #28a745;
        }

        .approve-btn:hover {
            background-color: #218838;
        }

        .delete-btn {
            background-color: #dc3545;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }

        .view-btn {
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            background-color: #007bff;
            color: #fff;
            border: none;
            transition: background-color 0.3s ease;
        }

        .view-btn:hover {
            background-color: #0056b3;
        }

        .stats {
            text-align: center;
            margin: 20px 0;
        }

        .stats div {
            display: inline-block;
            margin: 10px;
            padding: 10px;
            background-color: #eee;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <h1>Admin Panel - Manage Volunteers</h1>

        <div class="search-bar">
            <form action="admin.php" method="GET">
                <input type="text" name="search" placeholder="Search by username or email" value="<?= htmlspecialchars($search_query) ?>">
                <button type="submit" class="view-btn">Search</button>
            </form>
        </div>

        <div class="stats">
            <div>Total Volunteers: <?= count($volunteers) ?></div>
            <div>Approved Volunteers: <?= count(array_filter($volunteers, fn($v) => $v['is_approved'])) ?></div>
            <div>Pending Approvals: <?= count(array_filter($volunteers, fn($v) => !$v['is_approved'])) ?></div>
        </div>

        <?php if (count($volunteers) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Approval Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($volunteers as $volunteer): ?>
                        <tr>
                            <td><?= $volunteer['id'] ?></td>
                            <td><?= htmlspecialchars($volunteer['username']) ?></td>
                            <td><?= htmlspecialchars($volunteer['email']) ?></td>
                            <td><?= $volunteer['is_approved'] ? 'Approved' : 'Pending' ?></td>
                            <td>
                                <form action="admin.php" method="POST" style="display:inline-block;">
                                    <input type="hidden" name="volunteer_id" value="<?= $volunteer['id'] ?>">
                                    <input type="hidden" name="is_approved" value="<?= $volunteer['is_approved'] ?>">
                                    <button type="submit" name="toggle_approval" class="approve-btn">
                                        <?= $volunteer['is_approved'] ? 'Unapprove' : 'Approve' ?>
                                    </button>
                                </form>
                                <form action="admin.php" method="POST" style="display:inline-block;">
                                    <input type="hidden" name="volunteer_id" value="<?= $volunteer['id'] ?>">
                                    <button type="submit" name="delete_volunteer" class="delete-btn" onclick="return confirm('Are you sure you want to delete this volunteer?');">
                                        Delete
                                    </button>
                                </form>
                                <form action="view_volunteer.php" method="GET" style="display:inline-block;">
                                    <input type="hidden" name="volunteer_id" value="<?= $volunteer['id'] ?>">
                                    <button type="submit" class="view-btn">View</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No volunteers found.</p>
        <?php endif; ?>
    </div>
</body>
</html>
