<?php
session_start();

if (!isset($_SESSION['volunteer_logged_in'])) {
    header('Location: auth.php');
    exit();
}

// Fetch volunteer details
require_once '../config/db.php';
$stmt = $pdo->prepare("SELECT * FROM volunteers WHERE id = ?");
$stmt->execute([$_SESSION['volunteer_id']]);
$volunteer = $stmt->fetch(PDO::FETCH_ASSOC);

$is_approved = $volunteer['is_approved']; // Get the approval status

// Fetch announcements
$announcements_stmt = $pdo->query("SELECT a.*, v.username AS created_by FROM announcements a JOIN volunteers v ON a.created_by = v.id ORDER BY a.created_at DESC");
$announcements = $announcements_stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch orders if the user is approved
$orders = [];
if ($is_approved) {
    $orders_stmt = $pdo->prepare("SELECT o.*, h.name AS hospital_name, w.username AS warehouse_volunteer, d.username AS delivery_volunteer 
                                  FROM orders o 
                                  LEFT JOIN hospitals h ON o.hospital_id = h.id 
                                  LEFT JOIN volunteers w ON o.warehouse_volunteer_id = w.id 
                                  LEFT JOIN volunteers d ON o.delivery_volunteer_id = d.id
                                  WHERE o.volunteer_id = ?");
    $orders_stmt->execute([$_SESSION['volunteer_id']]);
    $orders = $orders_stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Handle post requests for updating profile, commenting, reacting, and placing orders
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_profile'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $address = $_POST['address'];
        $phone_number = $_POST['phone_number'];

        // Check if the email is already in use by another volunteer
        $email_check_stmt = $pdo->prepare("SELECT id FROM volunteers WHERE email = ? AND id != ?");
        $email_check_stmt->execute([$email, $_SESSION['volunteer_id']]);
        if ($email_check_stmt->rowCount() > 0) {
            echo "Error: The email address is already in use by another account.";
        } else {
            // Check if the profile photo is being uploaded
            if (isset($_FILES['profile_photo']) && !empty($_FILES['profile_photo']['name'])) {
                $profile_photo = 'uploads/' . basename($_FILES['profile_photo']['name']);
                if (!move_uploaded_file($_FILES['profile_photo']['tmp_name'], $profile_photo)) {
                    die("Failed to upload file.");
                }
            } else {
                $profile_photo = $volunteer['profile_photo'];
            }

            // Update volunteer data in the database
            $stmt = $pdo->prepare("UPDATE volunteers SET username = ?, email = ?, address = ?, phone_number = ?, profile_photo = ? WHERE id = ?");
            $stmt->execute([$username, $email, $address, $phone_number, $profile_photo, $_SESSION['volunteer_id']]);

            // Redirect to the dashboard after the profile update
            header('Location: dashboard.php');
            exit();
        }
    }

    if (isset($_POST['place_order'])) {
        $item_name = $_POST['item_name'];
        $quantity = $_POST['quantity'];
        $hospital_id = $_POST['hospital_id']; // Added to capture the hospital location

        $stmt = $pdo->prepare("INSERT INTO orders (volunteer_id, hospital_id, status) VALUES (?, ?, 'pending')");
        $stmt->execute([$_SESSION['volunteer_id'], $hospital_id]);
        
        // Fetch the last inserted order ID
        $order_id = $pdo->lastInsertId();  // Correct usage of lastInsertId()

        // Insert order items
        $stmt = $pdo->prepare("INSERT INTO order_items (order_id, item_name, quantity) VALUES (?, ?, ?)");
        $stmt->execute([$order_id, $item_name, $quantity]);

        header('Location: dashboard.php');
        exit();
    }
    

    // Mark order as received by the volunteer
    if (isset($_POST['mark_received'])) {
        $order_id = $_POST['order_id'];
        $stmt = $pdo->prepare("UPDATE orders SET status = 'received' WHERE id = ?");
        $stmt->execute([$order_id]);

        header('Location: dashboard.php');
        exit();
    }

    // Mark order as ready for delivery by warehouse volunteer
    if (isset($_POST['mark_ready'])) {
        $order_id = $_POST['order_id'];
        $warehouse_volunteer_id = $_SESSION['volunteer_id'];
        $stmt = $pdo->prepare("UPDATE orders SET status = 'ready', warehouse_volunteer_id = ? WHERE id = ?");
        $stmt->execute([$warehouse_volunteer_id, $order_id]);

        header('Location: dashboard.php');
        exit();
    }

    // Mark order as out for delivery by delivery volunteer
    if (isset($_POST['mark_delivery'])) {
        $order_id = $_POST['order_id'];
        $delivery_volunteer_id = $_SESSION['volunteer_id'];
        $approx_delivery_time = $_POST['approx_delivery_time']; // Capture the approximate delivery time

        $stmt = $pdo->prepare("UPDATE orders SET status = 'out for delivery', delivery_volunteer_id = ?, approx_delivery_time = ? WHERE id = ?");
        $stmt->execute([$delivery_volunteer_id, $approx_delivery_time, $order_id]);

        header('Location: dashboard.php');
        exit();
    }

    // Mark order as delivered
    if (isset($_POST['mark_delivered'])) {
        $order_id = $_POST['order_id'];
        $stmt = $pdo->prepare("UPDATE orders SET status = 'delivered' WHERE id = ?");
        $stmt->execute([$order_id]);

        header('Location: dashboard.php');
        exit();
    }

    // Handle announcements
    if (isset($_POST['post_announcement'])) {
        $title = $_POST['title'];
        $content = $_POST['content'];
        $stmt = $pdo->prepare("INSERT INTO announcements (title, content, created_by) VALUES (?, ?, ?)");
        $stmt->execute([$title, $content, $_SESSION['volunteer_id']]);
        header('Location: dashboard.php');
        exit();
    }

    // Editing an announcement
    if (isset($_POST['edit_announcement'])) {
        $announcement_id = $_POST['announcement_id'];
        $title = $_POST['title'];
        $content = $_POST['content'];
        $stmt = $pdo->prepare("UPDATE announcements SET title = ?, content = ? WHERE id = ? AND created_by = ?");
        $stmt->execute([$title, $content, $announcement_id, $_SESSION['volunteer_id']]);
        header('Location: dashboard.php');
        exit();
    }

    // Deleting an announcement
    if (isset($_POST['delete_announcement'])) {
        $announcement_id = $_POST['announcement_id'];
        $stmt = $pdo->prepare("DELETE FROM announcements WHERE id = ? AND created_by = ?");
        $stmt->execute([$announcement_id, $_SESSION['volunteer_id']]);
        header('Location: dashboard.php');
        exit();
    }

    // Commenting on an announcement
    if (isset($_POST['comment'])) {
        $comment = $_POST['comment'];
        $announcement_id = $_POST['announcement_id'];
        $stmt = $pdo->prepare("INSERT INTO comments (announcement_id, volunteer_id, comment) VALUES (?, ?, ?)");
        $stmt->execute([$announcement_id, $_SESSION['volunteer_id'], $comment]);
        header('Location: dashboard.php');
        exit();
    }

    // Reacting to an announcement
    if (isset($_POST['react'])) {
        $announcement_id = $_POST['announcement_id'];
        $stmt = $pdo->prepare("INSERT INTO reactions (announcement_id, volunteer_id, reaction_type) VALUES (?, ?, 'love')");
        $stmt->execute([$announcement_id, $_SESSION['volunteer_id']]);
        header('Location: dashboard.php');
        exit();
    }

    // Deleting a comment
    if (isset($_POST['delete_comment'])) {
        $comment_id = $_POST['comment_id'];
        $stmt = $pdo->prepare("DELETE FROM comments WHERE id = ? AND volunteer_id = ?");
        $stmt->execute([$comment_id, $_SESSION['volunteer_id']]);
        header('Location: dashboard.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Dashboard</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Link to your CSS file -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .dashboard-container {
            display: flex;
            max-width: 1200px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .main-content, .side-section {
            padding: 20px;
        }

        .main-content {
            flex: 3;
            margin-right: 20px;
        }

        .side-section {
            flex: 1;
            background-color: #f9f9f9;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 300px; /* Restricting the width of the section */
        }

        .side-section img {
            display: block;
            margin: 0 auto 15px auto; /* Centering the profile image */
            border-radius: 50%;
            width: 100px; /* Smaller profile image */
            height: 100px; /* Smaller profile image */
        }

        .side-section h2 {
            font-size: 18px; /* Smaller title */
            text-align: center;
            margin-bottom: 15px;
        }

        .side-section .form-group {
            margin-bottom: 10px; /* Reduce space between form groups */
        }

        .side-section .form-group label {
            font-size: 14px; /* Smaller label text */
        }

        .side-section .form-group input[type="text"],
        .side-section .form-group input[type="email"],
        .side-section .form-group input[type="file"],
        .side-section .form-group input[type="number"] {
            width: 100%;
            padding: 8px; /* Smaller input padding */
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 14px; /* Smaller input text */
        }

        .side-section .form-group button {
            width: 100%;
            padding: 8px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            font-size: 14px; /* Smaller button text */
        }

        .side-section .form-group button:hover {
            background-color: #218838;
        }

        .dashboard-section {
            margin-top: 30px;
        }

        .dashboard-section h2 {
            font-size: 20px;
            margin-bottom: 15px;
            color: #007bff;
            border-bottom: 2px solid #007bff;
            padding-bottom: 5px;
        }

        .dashboard-section p, .dashboard-section ul, .dashboard-section table {
            margin: 10px 0;
            padding: 0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .form-group input[type="text"], .form-group input[type="email"], .form-group input[type="file"], .form-group input[type="number"], .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }

        .form-group button {
            padding: 10px 20px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-group button:hover {
            background-color: #218838;
        }

        .order-section table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .order-section th, .order-section td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .order-section th {
            background-color: #f1f1f1;
        }

        .announcement {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
            position: relative;
        }

        .announcement h3 {
            margin: 0 0 10px 0;
            font-size: 18px;
        }

        .announcement p {
            margin: 0 0 10px 0;
            font-size: 14px;
            color: #555;
        }

        .announcement small {
            color: #999;
        }

        .announcement-actions {
            margin-top: 10px;
        }

        .announcement-actions form {
            display: inline-block;
            margin-right: 10px;
        }

        .comment-actions form {
            display: inline-block;
            margin-right: 5px;
        }

        .announcement-edit {
            position: absolute;
            top: 10px;
            right: 10px;
        }

        .logout-btn {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #ff4c4c;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            display: inline-block;
            width: 100%;
            text-align: center;
        }

        .logout-btn:hover {
            background-color: #ff1a1a;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="main-content">
            <h1>Welcome, <?= htmlspecialchars($volunteer['username']) ?></h1>

            <?php if ($is_approved): ?>
                <p>Your account has been approved. You now have full access to the dashboard features.</p>

                <!-- Announcement Section -->
                <div class="dashboard-section announcement-section">
                    <h2>Announcements</h2>

                    <!-- Form to post an announcement -->
                    <div class="announcement">
                        <h3>Post a New Announcement</h3>
                        <form action="dashboard.php" method="POST">
                            <div class="form-group">
                                <label for="title">Title:</label>
                                <input type="text" name="title" required>
                            </div>
                            <div class="form-group">
                                <label for="content">Content:</label>
                                <textarea name="content" required></textarea>
                            </div>
                            <div class="form-group">
                                <button type="submit" name="post_announcement">Post Announcement</button>
                            </div>
                        </form>
                    </div>

                    <!-- Display announcements -->
                    <?php foreach ($announcements as $announcement): ?>
                        <div class="announcement">
                            <h3><?= htmlspecialchars($announcement['title']) ?></h3>
                            <p><?= htmlspecialchars($announcement['content']) ?></p>
                            <p><small>Posted by: <?= htmlspecialchars($announcement['created_by']) ?> on <?= htmlspecialchars($announcement['created_at']) ?></small></p>

                            <?php if ($announcement['created_by'] == $volunteer['username']): ?>
                                <!-- Edit/Delete buttons for the author -->
                                <div class="announcement-edit">
                                    <form action="dashboard.php" method="POST" style="display:inline;">
                                        <input type="hidden" name="announcement_id" value="<?= $announcement['id'] ?>">
                                        <button type="submit" name="delete_announcement">Delete</button>
                                    </form>
                                    <form action="dashboard.php" method="POST" style="display:inline;">
                                        <input type="hidden" name="announcement_id" value="<?= $announcement['id'] ?>">
                                        <input type="text" name="title" value="<?= htmlspecialchars($announcement['title']) ?>" required>
                                        <textarea name="content" required><?= htmlspecialchars($announcement['content']) ?></textarea>
                                        <button type="submit" name="edit_announcement">Edit</button>
                                    </form>
                                </div>
                            <?php endif; ?>

                            <!-- React and comment form -->
                            <div class="announcement-actions">
                                <form action="dashboard.php" method="POST">
                                    <input type="hidden" name="announcement_id" value="<?= $announcement['id'] ?>">
                                    <button type="submit" name="react">❤️ Love</button>
                                </form>
                                <form action="dashboard.php" method="POST">
                                    <input type="hidden" name="announcement_id" value="<?= $announcement['id'] ?>">
                                    <input type="text" name="comment" placeholder="Add a comment..." required>
                                    <button type="submit" name="comment">Comment</button>
                                </form>
                            </div>

                            <!-- Display comments -->
                            <h4>Comments:</h4>
                            <?php
                            $comments_stmt = $pdo->prepare("SELECT c.*, v.username FROM comments c JOIN volunteers v ON c.volunteer_id = v.id WHERE announcement_id = ? ORDER BY c.created_at DESC");
                            $comments_stmt->execute([$announcement['id']]);
                            $comments = $comments_stmt->fetchAll(PDO::FETCH_ASSOC);
                            ?>
                            <?php foreach ($comments as $comment): ?>
                                <p><b><?= htmlspecialchars($comment['username']) ?>:</b> <?= htmlspecialchars($comment['comment']) ?> <small><?= htmlspecialchars($comment['created_at']) ?></small></p>
                                <?php if ($comment['username'] == $volunteer['username']): ?>
                                    <div class="comment-actions">
                                        <form action="dashboard.php" method="POST">
                                            <input type="hidden" name="comment_id" value="<?= $comment['id'] ?>">
                                            <button type="submit" name="delete_comment">Delete</button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Order Section -->
<div class="dashboard-section order-section">
    <h2>Place an Order</h2>
    <form action="dashboard.php" method="POST">
        <div class="form-group">
            <label for="item_category">Item Category:</label>
            <select name="item_category" id="item_category" required>
                <option value="">Select Category</option>
                <option value="clothing">Clothing</option>
                <option value="medical">Medical Supplies</option>
                <option value="food">Food</option>
                <!-- Add more categories as needed -->
            </select>
        </div>

        <div class="form-group">
            <label for="item_name">Item Name:</label>
            <select name="item_name" id="item_name" required>
                <!-- Dynamically populated based on category selection -->
            </select>
        </div>

        <div class="form-group">
            <label for="size">Size (if applicable):</label>
            <select name="size" id="size">
                <option value="">Select Size</option>
                <option value="small">Small</option>
                <option value="medium">Medium</option>
                <option value="large">Large</option>
                <!-- Add more sizes as needed -->
            </select>
        </div>

        <div class="form-group">
            <label for="quantity">Quantity:</label>
            <input type="number" name="quantity" required min="1">
        </div>

        <div class="form-group">
            <label for="hospital_id">Hospital:</label>
            <select name="hospital_id" required>
                <option value="1">Hospital A</option>
                <option value="2">Hospital B</option>
                <option value="3">Hospital C</option>
                <!-- Add more hospitals as needed -->
            </select>
        </div>

        <div class="form-group">
            <label for="recipient_name">Recipient Name:</label>
            <input type="text" name="recipient_name" required>
        </div>

        <div class="form-group">
            <label for="additional_notes">Additional Notes:</label>
            <textarea name="additional_notes" placeholder="Any special instructions or details"></textarea>
        </div>

        <div class="form-group">
            <button type="submit" name="place_order">Place Order</button>
        </div>
    </form>

    <h2>Your Orders</h2>
    <?php if (count($orders) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Status</th>
                    <th>Items</th>
                    <th>Location</th>
                    <th>Warehouse Volunteer</th>
                    <th>Delivery Volunteer</th>
                    <th>Approx. Delivery Time</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?= $order['id'] ?></td>
                        <td><?= $order['status'] ?></td>
                        <td>
                            <ul>
                                <?php
                                $items_stmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
                                $items_stmt->execute([$order['id']]);
                                $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
                                foreach ($items as $item):
                                ?>
                                    <li><?= htmlspecialchars($item['item_name']) ?> (x<?= $item['quantity'] ?>) - <?= htmlspecialchars($item['status']) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </td>
                        <td><?= htmlspecialchars($order['hospital_name']) ?></td>
                        <td><?= htmlspecialchars($order['warehouse_volunteer']) ?></td>
                        <td><?= htmlspecialchars($order['delivery_volunteer']) ?></td>
                        <td><?= htmlspecialchars($order['approx_delivery_time']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>You have not placed any orders yet.</p>
    <?php endif; ?>
</div>

<script>
// Example script to dynamically populate item names based on category
document.getElementById('item_category').addEventListener('change', function () {
    const category = this.value;
    const itemNameSelect = document.getElementById('item_name');

    // Clear previous options
    itemNameSelect.innerHTML = '';

    if (category === 'clothing') {
        itemNameSelect.innerHTML += '<option value="tshirt">T-Shirt</option>';
        itemNameSelect.innerHTML += '<option value="jacket">Jacket</option>';
        itemNameSelect.innerHTML += '<option value="hat">Hat</option>';
    } else if (category === 'medical') {
        itemNameSelect.innerHTML += '<option value="gloves">Gloves</option>';
        itemNameSelect.innerHTML += '<option value="mask">Mask</option>';
        itemNameSelect.innerHTML += '<option value="firstaid">First Aid Kit</option>';
    } else if (category === 'food') {
        itemNameSelect.innerHTML += '<option value="canned_food">Canned Food</option>';
        itemNameSelect.innerHTML += '<option value="water">Water</option>';
        itemNameSelect.innerHTML += '<option value="snacks">Snacks</option>';
    }
    // Add more categories and items as needed
});
</script>


            <?php else: ?>
                <p>Your account is pending approval from an admin. Please check back later.</p>
                <div class="pending-approval">
                    <p>Note: You will receive an email notification once your account has been approved.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Side Section -->
        <div class="side-section">
            <h2>My Account</h2>
            <form action="dashboard.php" method="POST" enctype="multipart/form-data">
                <img src="<?= htmlspecialchars($volunteer['profile_photo'] ?: 'default_profile.png') ?>" alt="Profile Photo">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" name="username" value="<?= htmlspecialchars($volunteer['username']) ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" name="email" value="<?= htmlspecialchars($volunteer['email']) ?>" required>
                </div>
                <div class="form-group">
                    <label for="address">Address:</label>
                    <input type="text" name="address" value="<?= htmlspecialchars($volunteer['address']) ?>">
                </div>
                <div class="form-group">
                    <label for="phone_number">Phone Number:</label>
                    <input type="text" name="phone_number" value="<?= htmlspecialchars($volunteer['phone_number']) ?>">
                </div>
                <div class="form-group">
                    <label for="profile_photo">Profile Photo:</label>
                    <input type="file" name="profile_photo">
                </div>
                <div class="form-group">
                    <button type="submit" name="update_profile">Update Profile</button>
                </div>
            </form>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>

    </div>
</body>
</html>
