<?php
session_start();
require_once '../config/db.php';

if (!isset($_GET['volunteer_id'])) {
    header('Location: admin.php');
    exit();
}

$volunteer_id = $_GET['volunteer_id'];
$stmt = $pdo->prepare("SELECT * FROM volunteers WHERE id = ?");
$stmt->execute([$volunteer_id]);
$volunteer = $stmt->fetch();

if (!$volunteer) {
    header('Location: admin.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Details</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Add your own styles here -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .volunteer-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .profile-photo {
            display: block;
            margin: 0 auto 20px;
            border-radius: 50%;
            width: 150px;
            height: 150px;
            object-fit: cover;
            background-color: #e9e9e9;
        }

        .detail {
            margin-bottom: 10px;
        }

        .back-btn {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            text-align: center;
            border-radius: 5px;
        }

        .back-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="volunteer-container">
        <h1>Volunteer Details</h1>
        <?php if (!empty($volunteer['profile_photo'])): ?>
            <img src="<?= htmlspecialchars($volunteer['profile_photo']) ?>" alt="Profile Photo" class="profile-photo">
        <?php else: ?>
            <img src="default_profile.png" alt="Default Profile Photo" class="profile-photo">
        <?php endif; ?>
        <div class="detail"><strong>ID:</strong> <?= $volunteer['id'] ?></div>
        <div class="detail"><strong>Username:</strong> <?= htmlspecialchars($volunteer['username']) ?></div>
        <div class="detail"><strong>Email:</strong> <?= htmlspecialchars($volunteer['email']) ?></div>
        <div class="detail"><strong>Approval Status:</strong> <?= $volunteer['is_approved'] ? 'Approved' : 'Pending' ?></div>
        <div class="detail"><strong>Registered On:</strong> <?= htmlspecialchars($volunteer['created_at']) ?></div>
        <div class="detail"><strong>Address:</strong> <?= htmlspecialchars($volunteer['address']) ?></div>
        <div class="detail"><strong>Mobile Number:</strong> <?= htmlspecialchars($volunteer['phone_number']) ?></div>
        <a href="admin.php" class="back-btn">Back to Admin Panel</a>
    </div>
</body>
</html>
